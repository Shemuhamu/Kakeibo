class HouseholdAccount {
    //初期化、データの読み込み
    constructor() {
        this.data = this.loadData();
    }
    //ローカルからデータ取得
    loadData() {
        const saved = localStorage.getItem("householdData");
        return saved ? JSON.parse(saved) : { balance: 0, categories: [], history: [] };
    }
    //ローカルにデータ保存
    saveData() {
        localStorage.setItem("householdData", JSON.stringify(this.data));
    }
    //残高設定
    setInitialBalance(amount) {
        this.data.balance = amount;
        this.saveData();
    }
    //カテゴリ追加
    addCategory(category) {
        if (!this.data.categories.includes(category)) {// カテゴリが重複しないように
            this.data.categories.push(category);
            this.saveData();
        }
    }
    //支出登録
    addExpense(amount, category) {
        this.data.balance -= amount;
        this.data.history.push({
            date: new Date().toISOString().split('T')[0], // yyyy-mm-ddで日付を取得
            amount,
            category
        });
        this.saveData();
    }
    //残高取得
    getBalance() {
        return this.data.balance;
    }
    //カテゴリ取得
    getCategories() {
        return this.data.categories;
    }
    //履歴取得
    getHistory() {
        return this.data.history;
    }
    //履歴削除
    resetData() {
        this.data = { balance: 0, categories: [], history: [] };
        this.saveData();
    }
}

// -------------------------------
// イベント接続部分
// ---------------------------

const account = new HouseholdAccount();

// 残金設定:入力欄から金額取得 → setInitialBalance() 呼び出し → 残金更新
document.getElementById("setBalanceBtn").addEventListener("click", () => {
    const value = parseInt(document.getElementById("initialBalanceInput").value);　// 入力値取得
    // 入力値が数値で、0以上の場合のみ処理-はだめ
    if (!isNaN(value) && value >= 0) {
        account.setInitialBalance(value);
        updateBalance();//表示を更新
    }
});

// 支出登録:金額とカテゴリを入力 → addExpense() 呼び出し → 残金・カテゴリ合計更新
document.getElementById("addExpenseBtn").addEventListener("click", () => {
    const amount = parseInt(document.getElementById("expenseAmount").value);// 入力値取得
    const category = document.getElementById("expenseCategory").value;// カテゴリ取得
    if (!isNaN(amount) && amount > 0 && category) {// 金額とカテゴリが正しい場合
        account.addExpense(amount, category);
        updateBalance();
        updateCategoryTotals();// カテゴリ合計更新
    }
});

// カテゴリ追加:新カテゴリ入力 → addCategory() 呼び出し → カテゴリ合計更新
document.getElementById("addCategoryBtn").addEventListener("click", () => {
    const newCategory = document.getElementById("newCategory").value;
    if (newCategory) {
        account.addCategory(newCategory);
        updateCategoryTotals();
    }
});
//カテゴリごとの支出
function updateCategoryTotals() {
    const categories = account.getCategories();//getCategories()でカテゴリ取得
    const history = account.getHistory();//getHistory()で履歴取得
    // カテゴリごとの合計を計算
    const totals = {};
    categories.forEach(cat => totals[cat] = 0);
    history.forEach(entry => {
        if (totals.hasOwnProperty(entry.category)) {
            totals[entry.category] += entry.amount;
        }
    });
    //HTMLリストにカテゴリ＋合計額を表示
    const list = document.getElementById("categoryTotals");
    list.innerHTML = "";

    categories.forEach(cat => {
        const li = document.createElement("li");
        li.textContent = `${cat}: ${totals[cat]} 円 `;

        // --- 名前変更ボタン ---
        const renameBtn = document.createElement("button");
        renameBtn.textContent = "名前変更";
        renameBtn.style.marginLeft = "10px";
        renameBtn.addEventListener("click", () => {
            const newName = prompt("新しいカテゴリ名を入力してください：", cat);
            if (newName && newName !== cat && !categories.includes(newName)) {
                // カテゴリ名変更
                const data = account.data;
                // カテゴリリスト変更
                const index = data.categories.indexOf(cat);
                if (index !== -1) data.categories[index] = newName;
                // 履歴内のカテゴリ変更
                data.history.forEach(entry => {
                    if (entry.category === cat) entry.category = newName;
                });
                account.saveData();
                updateCategoryTotals();
            }
        });

        // --- 削除ボタン ---
        const deleteBtn = document.createElement("button");
        deleteBtn.textContent = "削除";
        deleteBtn.style.marginLeft = "5px";
        deleteBtn.addEventListener("click", () => {
            if (confirm(`カテゴリ「${cat}」を削除しますか？（履歴も削除されます）`)) {
                const data = account.data;
                // カテゴリ削除
                data.categories = data.categories.filter(c => c !== cat);
                // 該当履歴削除
                data.history = data.history.filter(entry => entry.category !== cat);
                account.saveData();
                updateCategoryTotals();
                const historyList = document.getElementById("historyList");
                historyList.innerHTML = "";
            }
        });

        // ボタン追加
        li.appendChild(renameBtn);
        li.appendChild(deleteBtn);
        list.appendChild(li);
    });
}



// 履歴表示:getHistory()で履歴取得 → 日時・カテゴリ・金額を一覧表示
document.getElementById("showHistoryBtn").addEventListener("click", () => {
    const history = account.getHistory();
    const list = document.getElementById("historyList");
    list.innerHTML = ""; // 初期化
    history.forEach(entry => {
        const li = document.createElement("li");
        li.textContent = `${entry.date} - ${entry.category}: ${entry.amount}円`;
        list.appendChild(li);
    });
});
//データリセット:confirm()で確認 → resetData()でデータ初期化 → 画面更新
document.getElementById("resetDataBtn").addEventListener("click", () => {
    if (confirm("本当に全データをリセットしますか？")) {
        account.resetData();
        updateBalance();
        updateCategoryTotals();
        const historyList = document.getElementById("historyList");
        historyList.innerHTML = "";
    }
});


function updateBalance() {
    document.getElementById("balance").textContent = account.getBalance();
}

// 初回読み込み: ページロード時に 残金とカテゴリ一覧を即表示
updateBalance();
updateCategoryTotals();

